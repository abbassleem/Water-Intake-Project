import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  double weight = 70;
  double temperature = 25;
  double drank = 0;

  double get recommended {
    double base = weight * 0.033;
    double extra = temperature > 25 ? (temperature - 25) * 0.1 : 0;
    return base + extra;
  }

  @override
  Widget build(BuildContext context) {
    double progress = (drank / recommended).clamp(0, 1);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView( // <-- FIXED: makes UI scrollable
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Daily Water Intake Coach",
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 25),

                // Weight
                const Text("Weight (kg)", style: TextStyle(fontSize: 18)),
                Slider(
                  value: weight,
                  min: 30,
                  max: 150,
                  divisions: 120,
                  label: weight.toStringAsFixed(0),
                  onChanged: (v) => setState(() => weight = v),
                ),
                const SizedBox(height: 20),

                // Temperature
                const Text("Temperature (°C)", style: TextStyle(fontSize: 18)),
                Slider(
                  value: temperature,
                  min: 0,
                  max: 45,
                  divisions: 45,
                  label: temperature.toStringAsFixed(0),
                  onChanged: (v) => setState(() => temperature = v),
                ),
                const SizedBox(height: 20),

                // Drank
                const Text("Water Drank Today (Liters)",
                    style: TextStyle(fontSize: 18)),
                Slider(
                  value: drank,
                  min: 0,
                  max: recommended + 1,
                  divisions: 30,
                  label: drank.toStringAsFixed(2),
                  onChanged: (v) => setState(() => drank = v),
                ),
                const SizedBox(height: 30),

                // Circular progress
                Center(
                  child: Column(
                    children: [
                      SizedBox(
                        width: 200,
                        height: 200,
                        child: CircularProgressIndicator(
                          value: progress,
                          strokeWidth: 15,
                          backgroundColor: Colors.grey.shade300,
                          color: Colors.blue,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        "${(progress * 100).toStringAsFixed(0)}%",
                        style: const TextStyle(
                            fontSize: 32, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "Goal: ${recommended.toStringAsFixed(2)} L",
                        style: const TextStyle(fontSize: 18),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // Tip box (no Expanded)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    temperature > 35
                        ? "Very hot weather. Drink more frequently and avoid direct sun."
                        : temperature > 25
                        ? "Warm day. Increase your water intake slightly."
                        : "Normal temperature. Maintain regular hydration.",
                    style: const TextStyle(fontSize: 18),
                  ),
                ),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
