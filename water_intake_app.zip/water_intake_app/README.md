# Daily Water Intake Coach — CSCI410 Project 1

Single-page Flutter app to compute recommended daily water intake and track progress. No database.

## Files to copy
- lib/main.dart
- lib/home_page.dart
- pubspec.yaml
- assets/placeholder_screenshot.png (optional)

## How to run in Android Studio
1. Install Flutter and Android Studio.
2. File → New → New Flutter Project → Flutter Application.
3. Project name: `water_intake_app`.
4. Replace `pubspec.yaml` and files under `lib/` with the files from this repo. Add the optional screenshot to `assets/`.
5. Run `flutter pub get`.
6. Connect a device or start an emulator and press Run ▶.

## What to submit
- GitHub repository URL (make the repo public)
- A short project report (you can copy the report I previously generated)

## Git commands (quick)
```
git init
git add .
git commit -m "Initial commit - Water Intake Coach"
git branch -M main
git remote add origin https://github.com/<your-username>/water-intake-coach.git
git push -u origin main
```

## Notes
- All logic is local state only; no backend required.
- The recommended formula used: `recommended = weight * 0.033 + extra` where `extra = max(0, temperature - 25) * 0.1`.
